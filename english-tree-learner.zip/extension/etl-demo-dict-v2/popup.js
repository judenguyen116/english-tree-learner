
function qs(s){return document.querySelector(s)}
function el(tag,attrs={},kids=[]){const n=document.createElement(tag);Object.entries(attrs).forEach(([k,v])=>k in n?n[k]=v:n.setAttribute(k,v));kids.forEach(c=>n.appendChild(typeof c==="string"?document.createTextNode(c):c));return n;}
async function getState(){return new Promise(res=>chrome.storage.sync.get({cards:[],lastSavedAt:0},d=>res(d)))}
async function setCards(cards){return new Promise(res=>chrome.storage.sync.set({cards},res))}

function mountTabs(){
  const tabs=[["#tab-review","#pane-review"],["#tab-saved","#pane-saved"],["#tab-garden","#pane-garden"],["#tab-claim","#pane-claim"]];
  tabs.forEach(([b,p])=>{
    qs(b).addEventListener("click",()=>{
      tabs.forEach(([bb,pp])=>{qs(bb).classList.toggle("active",bb===b);qs(pp).style.display=pp===p?"block":"none"});
      if(p==="#pane-review") renderReview();
      if(p==="#pane-saved") renderSaved();
      if(p==="#pane-garden") renderGarden();
      if(p==="#pane-claim") renderClaim();
    });
  });
}

async function renderReview(){
  const pane=qs("#pane-review"); pane.innerHTML="";
  const {cards=[]}=await getState();
  const due=cards.filter(c=>(c.dueAt||0)<=Date.now());
  if(!due.length){ pane.appendChild(el("div",{className:"card"},["Không có thẻ đến hạn. Hãy mở bài và nhấn Save từ."])); return; }
  const c=due[0];
  const audioBtn = c.audio ? el("button",{className:"audio-btn",onclick:()=>new Audio(c.audio).play()},["🔊 Play"]) : null;
  const head = el("div",{className:"row"},[ el("h3",{},[c.word]), c.phonetic? el("span",{className:"phon"},[`/${c.phonetic}/`]):null, audioBtn ].filter(Boolean));
  pane.appendChild(el("div",{className:"card"},[
    head,
    c.definition? el("div",{},[c.definition]) : el("div",{},["(Chưa có định nghĩa)"]),
    el("div",{className:"row",style:"margin-top:8px"},[
      el("button",{className:"bad",onclick:()=>grade(c,0)},["Again"]),
      el("button",{onclick:()=>grade(c,1)},["Hard"]),
      el("button",{className:"good",onclick:()=>grade(c,2)},["Good"]),
      el("button",{className:"easy",onclick:()=>grade(c,3)},["Easy"])
    ]),
    el("div",{},[el("small",{},["Ví dụ:"])]),
    el("ul",{},(c.examples||[]).slice(0,2).map(s=>el("li",{},[s])))
  ]));
  async function grade(card,g){
    card.dueAt = Date.now() + (g<2? 6*3600e3 : (g===2? 24*3600e3 : 3*24*3600e3));
    await setCards(cards); renderReview();
  }
}

async function renderSaved(){
  const pane=qs("#pane-saved"); pane.innerHTML="";
  const {cards=[]}=await getState();
  const top=el("div",{className:"row"},[
    el("input",{type:"text",placeholder:"Tìm từ…",id:"searchInput"}),
    el("button",{onclick:()=>exportJSON(cards)},["Export JSON"])
  ]);
  pane.appendChild(top);
  const list=el("div"); pane.appendChild(list);
  function paint(filter=""){
    list.innerHTML="";
    const xs=cards.filter(c=>c.word.includes(filter.toLowerCase())).sort((a,b)=>a.word.localeCompare(b.word));
    xs.forEach(c=>{
      const audioBtn = c.audio ? el("button",{className:"audio-btn",onclick:()=>new Audio(c.audio).play()},["🔊"]) : null;
      list.appendChild(el("div",{className:"card"},[
        el("div",{className:"row"},[ el("h3",{},[c.word]), c.phonetic? el("span",{className:"phon"},[`/${c.phonetic}/`]):null, audioBtn ].filter(Boolean)),
        c.definition? el("div",{},[c.definition]) : el("div",{},["(No definition)"]),
        el("div",{},[el("small",{},["Ví dụ:"])]),
        el("ul",{},(c.examples||[]).map(s=>el("li",{},[s]))),
        el("div",{className:"row"},[
          el("button",{onclick:async()=>{const next=(cards||[]).filter(x=>x.word!==c.word);await setCards(next);renderSaved();}},["Delete"])
        ])
      ]));
    });
  }
  paint();
  qs("#searchInput").addEventListener("input", e=>paint(e.target.value.trim()));
}

function exportJSON(cards){
  const blob = new Blob([JSON.stringify(cards,null,2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "etl-saved-words.json"; a.click();
  URL.revokeObjectURL(url);
}

async function renderGarden(){
  const pane=qs("#pane-garden"); pane.innerHTML="";
  const {lastSavedAt=0}=await getState();
  const days = Math.floor((Date.now()-(lastSavedAt||0))/(24*3600e3));
  const svg = `
  <div id="garden">
    <svg class="tree-svg" viewBox="0 0 200 240">
      <rect x="92" y="130" width="16" height="80" rx="6" fill="#6b3e1d"></rect>
      <g id="leaves">
        ${[0,1,2,3,4,5,6,7].map(i=>`<path class="leaf ${days>=i+1?(days>=i+2?'fallen':'wilted'):'healthy'}" data-index="${i}" d="M${40+20*i} ${60+(i%2?0:10)} C ${30+20*i} ${40}, ${70+20*i} ${50}, ${60+20*i} ${85} Z" fill="#2ecc71"></path>`).join("")}
      </g>
    </svg>
  </div>
  <div class="tree-info">Days inactive: ${days} • Dblclick vào từ trên trang để lưu nhanh.</div>`;
  pane.innerHTML = svg;
}

function levenshtein(a,b){const m=Array.from({length:a.length+1},(_,i)=>[i]);for(let j=0;j<b.length+1;j++)m[0][j]=j;for(let i=1;i<=a.length;i++){for(let j=1;j<=b.length;j++){const c=a[i-1]===b[j-1]?0:1;m[i][j]=Math.min(m[i-1][j]+1,m[i][j-1]+1,m[i-1][j-1]+c)} }return m[a.length][b.length]}
function mask(s,w){return s.replace(new RegExp(`\\b(${w.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\$&')})\\b`,'i'),"_____")}
async function renderClaim(){
  const pane=qs("#pane-claim"); pane.innerHTML="";
  const {cards=[]}=await getState();
  pane.appendChild(el("div",{className:"card"},[
    el("div",{},["Demo claim (offline): phải pass bài 20s."]),
    el("button",{onclick:()=>startQuickQuiz(cards)},["Start 20s Quiz"])
  ]));
  const modal = el("div",{id:"quizModal",className:"modal"},[
    el("div",{className:"modal-card"},[
      el("div",{style:"display:flex;justify-content:space-between;align-items:center;"},[el("h3",{},["Quick Quiz (20s)"]), el("div",{className:"timer",id:"quizTimer"},["20"])]),
      el("div",{id:"quizBody"}),
      el("div",{style:"display:flex;gap:8px;justify-content:flex-end;margin-top:8px;"},[el("button",{id:"quizCancel"},["Cancel"]), el("button",{id:"quizSubmit"},["Submit"])]),
      el("small",{},["Rời tab/ẩn cửa sổ = fail (demo)"])
    ])
  ]);
  document.body.appendChild(modal);

  function pick(cards,n=8){
    const pool = cards.filter(c=>(c.examples||[]).length);
    if (!pool.length){ alert("Cần lưu từ có ví dụ để làm quiz."); return []; }
    pool.sort(()=>Math.random()-0.5);
    return pool.slice(0, Math.min(n,pool.length)).map(c=>{
      const ex = c.examples[Math.floor(Math.random()*c.examples.length)]||c.word;
      return {word:c.word, prompt: mask(ex,c.word)};
    });
  }
  function antiCheat(modalEl, onFail){
    const fail=()=>onFail&&onFail();
    const onVis=()=>{ if (document.hidden) fail(); };
    const onBlur=()=>fail();
    const block=e=>e.preventDefault();
    modalEl.addEventListener("contextmenu", block);
    modalEl.addEventListener("copy", block);
    modalEl.addEventListener("paste", block);
    modalEl.addEventListener("cut", block);
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("blur", onBlur);
    return ()=>{
      modalEl.removeEventListener("contextmenu", block);
      modalEl.removeEventListener("copy", block);
      modalEl.removeEventListener("paste", block);
      modalEl.removeEventListener("cut", block);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("blur", onBlur);
    };
  }
  function startQuickQuiz(cards){
    const items = pick(cards,8); if (!items.length) return;
    const body=qs("#quizBody"); const timerEl=qs("#quizTimer");
    body.innerHTML="";
    items.forEach((it,i)=>{
      const q = el("div",{className:"q"},[ el("div",{},[`Q${i+1}. ${it.prompt}`]), el("input",{type:"text","data-ans":it.word}) ]);
      body.appendChild(q);
    });
    let t=20, ended=false; modal.classList.add("open");
    const disarm = antiCheat(modal, ()=>finish(true,"Left tab/window"));
    const tick = setInterval(()=>{ t-=1; timerEl.textContent=String(t); if (t<=0) finish(); },1000);
    qs("#quizCancel").onclick=()=>finish(true,"Cancelled");
    qs("#quizSubmit").onclick=()=>finish();
    function finish(forceFail=false, reason=""){
      if (ended) return; ended=true; clearInterval(tick); disarm(); modal.classList.remove("open");
      const inputs = Array.from(body.querySelectorAll("input"));
      let correct=0;
      if (!forceFail){
        for (const inp of inputs){
          const g=(inp.getAttribute("data-ans")||"").trim().toLowerCase();
          const p=(inp.value||"").trim().toLowerCase();
          if (!p) continue;
          const d=levenshtein(p,g);
          if (p===g || d<=1) correct++;
        }
      }
      const rate = correct/(inputs.length||1);
      if (forceFail || rate<0.8){
        alert(`Fail (${correct}/${inputs.length}). (Demo) Cây sẽ héo thêm.`);
      }else{
        alert("Pass! (demo) Bạn đã claim mock token.");
      }
    }
  }
}

document.addEventListener("DOMContentLoaded", async ()=>{
  mountTabs(); renderReview();
});
